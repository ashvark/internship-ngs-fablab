QIIME 1.9.1 Galaxy Wrapper
--------------------------

Note: Many of these tools output html files that will not display properly
unless sanitization is turned off in Galaxy. This can be done globally via the
`santize_all_html` option in `galaxy.ini` or on a per tool basis using the
`santize_whitelist_file` in `galaxy.ini`.
